def campusCup(emails):
    domains = {}
    for i in emails:
        domains.setdefault(i.split('@')[-1], []).append(i)
        
    for k,v in domains.items():
        points = len(v)*20
        if points>=100 and points<200:
            domains[k]= (points, 3)
        elif 300>points>=200:
            domains[k]= (points, 11)
        elif 500>points>=300:
            domains[k]= (points, 26)
        elif points>=500:
            domains[k]= (points, 49)
        else:            
            domains[k]= (points, 1)

    print(domains)
    items = sorted(domains, key=lambda x:(-domains[x][1],x))
    return [i for i in items]
