def launchSequenceChecker(systemNames, stepNumbers):
    
    d={}
    for i, v in enumerate(systemNames):        
        d.setdefault(v,[]).append(stepNumbers[i])
    for k,l in d.items():
        if l != list(sorted(set(l))) or l != sorted(l):
            return False
        
    return True
