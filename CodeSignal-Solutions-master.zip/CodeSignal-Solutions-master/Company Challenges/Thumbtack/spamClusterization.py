import re
from fractions import Fraction

def find_intersection(m_list):
    s=m_list
    for i,v in enumerate(m_list):
        for j,k in enumerate(m_list[i+1:],i+1):
            if v & k:
                s[i]=v.union(m_list.pop(j))
                return find_intersection(m_list)
    return m_list
    
def spamClusterization(requests, ids, threshold):
    req_d = []
    for req in requests:        
        req = req.lower().split(' ')
        req = re.sub(r'\W+', ' ', ' '.join(req))
        req = set(req.split(' '))
        req_d.append(req)        
        if '' in req:
            req.discard('')
                    
    ji =[[0]*len(requests) for i in range(len(requests))]
    for i in range(len(requests)):
        for j in range(len(requests)):
            if i!=j:
                intersection_ = len(req_d[i].intersection(req_d[j]))
                union_ = len(req_d[i].union(req_d[j]))
                ji[i][j]=intersection_/union_
            else:
                ji[i][j]=0

    tuple_list = []
    for i in range(len(ji)):
        for j in range(i, len(ji)):
            if i!=j and ji[i][j]>=threshold:
                tuple_list.append((i,j))

    s = [set(i) for i in tuple_list if i]    
    s = find_intersection(s)      

    for i in range(len(s)):
        s[i]=list(s[i])
        for j in range(len(s[i])):            
            s[i][j] = ids[s[i][j]]
    for i in range(len(s)):
	    s[i]=sorted(s[i])        
    return sorted(s)
