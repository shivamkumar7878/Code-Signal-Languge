from itertools import chain
def categoryRecommendations(requestData, proSelections):
    dicti={x:0 for x in list(chain(*requestData))}
    dicti_count={x:0 for x in list(chain(*requestData))}
    main_dict={x:0 for x in list(chain(*requestData))}
    
    for data in requestData:
        jin=len(set(data)&set(proSelections))/len(set(data)|set(proSelections))
        
        to_add=set(data)-set(proSelections)
        for item in to_add:
            dicti_count[item]+=1
            dicti[item]+=jin
    
    print(dicti_count)
        
    for x in main_dict.keys():
        div=dicti_count[x] if dicti_count[x]!=0 else 1
        main_dict[x]=dicti[x]/div
    
    value=[]
    maxi=max(main_dict.values())
    for x,y in main_dict.items():
        if y==maxi and maxi>0:
            value.append(x)
    
    
    ret =sorted(value)
    print("ret = ",ret)
    return ret[0] if ret else ""
        
        
        

