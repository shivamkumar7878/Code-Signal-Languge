def priceSuggestion(contractData):
    import numpy as np
    contractData=sorted(contractData)
    first=[contractData[i] for i in range(len(contractData)) if i<len(contractData)/2]
    second=[contractData[i] for i in range(len(contractData)) if i>=len(contractData)/2]
    answer = []
    
    try:
        return [math.floor(np.median(first)), math.ceil(np.median(second))]
    except:
        return []
      
    return (answer)
            
