import collections
def get_question_id(topicid, topicIds):
    question_ids=[]
    for i, x in enumerate(topicIds):
        if topicid in x:
            question_ids.append(i)
    return question_ids

def get_index_list_of_list(l, n, col=0):
    r=[]
    for i in l:        
        if n == i[col]:
            r.append(l.index(i))
    if len(r)==1:
        return r[0]
    else:
        return r
        

def mostViewedWriters(topicIds, answerIds, views):
    topics = set(i for j in topicIds for i in j)
    topics_answers = {}
    for topic in topics:
        question_ids = get_question_id(topic, topicIds)
        for question in question_ids:
            topics_answers.setdefault(topic, []).extend(answerIds[question])
    #print(topics_answers)
    ans = {}
    user_views={}
    
    for k,values_in_topics_answers in topics_answers.items():
        if len(values_in_topics_answers)==0:
            user_views.setdefault(k, [])        
        for answer_id in values_in_topics_answers:
            users = user_views.get(k)
            view = get_index_list_of_list(views,answer_id,col=0)
            
            if users==None:                                                
                temp = [views[view][1],views[view][2]]
                user_views.setdefault(k, []).append(temp)
            elif not any(e[0] == views[view][1] for e in list(users)):
                temp = [views[view][1],views[view][2]]
                user_views.setdefault(k, []).append(temp)
            else:                        
                view_with_same_user_id = get_index_list_of_list(views, views[view][1],col=1)
                total_views = 0
                for i in view_with_same_user_id:
                    if views[i][0] in values_in_topics_answers:
                        total_views+=views[i][2]                        
                    
                temp=user_views.get(k)
                temp.pop(get_index_list_of_list(temp, views[view][1]))
                temp.append([views[view][1],total_views])
                user_views[k]=temp                       
                                           
    for k,v in user_views.items():
        user_views[k]=sorted(v,key=lambda x: (-x[1],x[0]) if len(x)!=0 else x)

    user_views=collections.OrderedDict(sorted(user_views.items()))
    return list(user_views.values())
