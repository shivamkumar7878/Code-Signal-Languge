def smartAssigning(names, statuses, projects, tasks):
    l = zip(names,statuses,projects,tasks)
    l = list(filter(lambda x: x[1] is False, list(l)))
    s = sorted(l, key = lambda x: (x[3], x[2]))
    return(s[0][0])
