def tasksTypes(deadlines, day):
    today=0
    upcoming=0
    later=0
    for i in deadlines:
        if i>day and i<=day+7:
            upcoming+=1
        elif i<=day:
            today+=1
        else:
            later+=1
            
    return [today,upcoming,later]
