def amendTheSentence(s):
    import re
    return ' '.join(filter(None, re.split("([A-Z][^A-Z]*)", s))).lower()
