def findFirstSubstringOccurrence(s, x):
    if x not in s:
        return -1
    else:
        return s.index(x)
