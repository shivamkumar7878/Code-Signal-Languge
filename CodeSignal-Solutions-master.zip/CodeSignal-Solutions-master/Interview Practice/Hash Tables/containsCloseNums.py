def containsCloseNums(nums, k):
    last_seen = dict()
    for pos, num in enumerate(nums):
        try:
            if pos - last_seen[num] <= k: return (True)
        except:
            pass
        last_seen[num] = pos

    return (False)
