def groupingDishes(dishes):
    ingredients=[]
    for i in dishes:
        for j in i[1:]:
            ingredients.append(j)
    items=[]
    for i in dishes:
        items.append(i[0])
    
    answer=[]
    counter=0
    for k in sorted(set(ingredients)):
        if ingredients.count(k)>1:
            answer.append([k])  
    
    for i in range(0,len(answer)):
        for j in sorted(dishes):
            if answer[i][0] in j[1:]:
                answer[i].append(j[0])
    
    return answer
