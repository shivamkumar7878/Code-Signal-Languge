def sudoku2(grid):
    import numpy as np
    not_in_row=True
    not_in_col=True
    numbers = ["."]
    grid_array = np.array(grid)
    
    for grid_row in grid:
        if not_in_row:
            for j in range(0,len(grid_row)):
                if grid_row[j] not in numbers:
                    numbers.append(grid_row[j])
                if grid_row[j]!='.' and (grid_row[j] in grid_row[j+1:] or grid_row[j] in grid_row[0:j]):
                    not_in_row = False
    col_grid=[]
    for i in range(0,len(grid[0])):
        col_grid.append(column(grid,i))
    for i in col_grid:
        if i[j] not in numbers:
            numbers.append(i[j])
        if not_in_col:            
            for j in range(0,len(i)):
                if i[j]!='.' and (i[j] in i[j+1:] or i[j]  in i[0:j]):
                    not_in_col = False
    dup =[] 
    for i in range(0,7):
        counter=0
        if i%3==0:
            for j in [3,6,9]:     
                ga = grid_array[i:i+3,counter:j]
                seen, dups = set(), set()
                for l in ga:
                    dups = dups.union(seen.intersection(set(l)))
                    seen = seen.union(set(l))
                    if "." in dups:
                        dups.remove(".")
                    if list(dups):
                        dup.append(list(dups))
                counter = counter+3
        
    return not_in_col and not_in_row and (not dup)
def column(matrix, i):
    return [row[i] for row in matrix]
                
