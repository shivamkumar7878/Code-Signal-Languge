def firstDuplicate(a):
    found = 0
    for i in range (0 , len(a)):
        item = abs(a[i])
        if(a[item - 1] > 0):
            a[item - 1] = -1 * a[item - 1]
        else:
            found = abs(a[i])
            break    
    return found if found!=0 else -1
