def firstNotRepeatingCharacter(s):
    count=0
    for i in range(0,len(s)):
        if s[i] in s[i+1:] or s[i] in s[:i-1] :
            count+=1
        else:
            return s[i]
    if count==len(s):
        return '_'

