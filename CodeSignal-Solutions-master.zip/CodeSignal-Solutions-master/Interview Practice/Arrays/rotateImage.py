def rotateImage(a):
    fv=zip(*a[::-1])
    print(fv)
