def countSetBits(n):
    count = 0
    while (n):
        n &= (n-1)
        count+=1
    return count

def findProfession(level, pos):
    c = countSetBits(pos-1)
    return 'Engineer' if c%2==0 else 'Doctor'
