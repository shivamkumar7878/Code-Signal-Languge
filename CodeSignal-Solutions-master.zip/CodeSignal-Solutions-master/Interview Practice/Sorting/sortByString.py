def sortByString(s, t):
    indices = {c: i for i, c in enumerate(t)}    
    return(''.join(sorted(s, key=indices.get)))
