def sortedSquaredArray(array):
    ans=[]
    for i in array:
        ans.append(i*i)
    return sorted(ans)
