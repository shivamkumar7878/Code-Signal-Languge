def higherVersion2(ver1, ver2):
    ver1_s,ver2_s="",""
    for i in ver1.split("."):
        ver1_s+=str(int(i))
    for i in ver2.split("."):
        ver2_s+=str(int(i))
    if int(ver1_s)>int(ver2_s):
        return 1
    elif int(ver1_s)<int(ver2_s):
        print(ver1_s,ver2_s)
        return -1
    else:
        return 0
