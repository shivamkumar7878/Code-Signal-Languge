def removeKFromList(l, k):
    temp = []
    while l is not None:
        if l.value != k:
            temp.append(l.value)
        l = l.next

    return(temp)   
