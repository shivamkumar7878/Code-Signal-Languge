def addTwoHugeNumbers(a, b):

    s,s1=0,0
    strs = ""
    strb = ""
    while a is not None:
        s+=1
        strs+=str(a.value).zfill(4)
        a=a.next
    
    while b is not None:
        s1+=1
        strb+=str(b.value).zfill(4)
        b=b.next
        
    ans = str(int(strs)+int(strb))
    
    temp=[ans[::-1][i:i+4] for i in range(0, len(ans[::-1]), 4)]
    ans1=[]
    for i in temp:
        ans1.append(int(i[::-1]))
    ans1=ans1[::-1]
    return ans1
    
