def reverseNodesInKGroups(l, k):
    list_l=[]
    while l:
        list_l.append(l.value)
        l=l.next
    output=[]
    for start in range(0,len(list_l),k):
        end=start+k
        temp=list_l[start:end]
        if len(temp)<k:
            output+=temp[:]
        else:
            output+=temp[::-1]
    return(output)
        
