def isListPalindrome(l):
    output = []
    
    while l is not None:
        output.append(l.value)
        l=l.next
    return output==output[::-1]
