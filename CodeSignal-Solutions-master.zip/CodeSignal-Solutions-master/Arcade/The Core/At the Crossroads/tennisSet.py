def tennisSet(score1, score2):
    return (score1<5 and score2==6) or (score1==6 and score2<5) or (( 7 > score1 >=5 and score2==7) or (7 > score2 >= 5 and score1 ==7)) 
