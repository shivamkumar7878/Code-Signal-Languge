def extraNumber(a, b, c):
    return a if b==c else b if a==c else c
