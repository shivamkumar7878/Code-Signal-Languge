def willYou(young, beautiful, loved):
    return ((young and beautiful) and not loved) or (loved and not (beautiful and young))
