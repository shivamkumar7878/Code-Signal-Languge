def metroCard(lastNumberOfDays):
    months = [31,28,31,30,31,30,31,31,30,31,30,31]
    if lastNumberOfDays == 31:
        list = []
        list.append(months[1])
        list.append(months[3])
        list.append(months[0])
        return list
    else:
        return [31]
