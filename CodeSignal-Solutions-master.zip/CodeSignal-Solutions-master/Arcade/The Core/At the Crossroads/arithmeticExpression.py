def arithmeticExpression(A, B, C):
    if A+B == C:
        return True
    elif A - B == C:
        return True
    elif A * B == C:
        return True
    elif A/B == C:
        return True
    else:
        return False
