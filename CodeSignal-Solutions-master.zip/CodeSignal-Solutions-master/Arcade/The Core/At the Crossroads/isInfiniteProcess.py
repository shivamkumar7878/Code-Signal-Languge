def isInfiniteProcess(a, b):
    if a>b:
            return True
    else:
        if (b-a)%2==0:
            return False
        else:
            return True
