def squareDigitsSequence(a0):
    arr = 0
    aa = [int(i) for i in str(a0)]
    array = [a0]    
    count=0
    while arr not in array[:-1]:               
        arr = 0 
        for i in aa:            
            arr += i*i
        array.append(arr)        
        aa = [int(i) for i in str(arr)]                
        count+=1       
    return count+1
