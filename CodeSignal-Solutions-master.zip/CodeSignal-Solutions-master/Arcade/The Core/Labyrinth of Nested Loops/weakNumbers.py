def weakNumbers(n):
    weakness = []
    for i in range(n+1):
        weakness.append(len([x for x in range(1,i+1) if i/x==int(i/x)]))
    weakness.pop(0)
    count =0 
    for i in reversed(range(0,n)):
        count =0 
        for j in range(0,i+1):
            if weakness[i] < weakness[j]:                
                count+=1
        weakness[i] = count
    
    
    return [max(weakness),weakness.count(max(weakness))]
