def pagesNumberingWithInk(current, numberOfDigits):
    while numberOfDigits != 0:
        if len(str(current)) <= numberOfDigits:
            digits = len(str(current))
            current+=1            
            numberOfDigits-=digits
        else:
            return current-1
    return current-1    
