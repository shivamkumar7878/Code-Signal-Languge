def isSumOfConsecutive2(n):
    elements = list(range(1,round(n/2)+2))
    suma=0
    count =0 
    for i in elements:
        print(i)
        suma = i
        for j in elements[1:]:
            if i < j:
                suma += j
                if suma == n:
                    count += 1               
                elif suma < n:
                    continue
                else:
                    j = len(elements)
    return count
