def comfortableNumbers(L, R):
    count=0
    v=[]
    di={}
    for i in range(L,R+1):
        di.update({str(i):sumSq(i)})
        
    for k in di:
        l=list(di[k])
        for ele in l:
            if str(ele) in di:
                if int(k) in list(di[str(ele)]):
                    count+=1
    return count/2
        
        
def sumSq(n):
    ss=0
    for i in range(len(str(n))):
        ss+=int(str(n)[i])
    l=[]
    for j in range(n-ss,n+ss+1):
        if j!=n:
            l.append(j) 
        
    return l
