def isPower(n):
    for a in range(50):
        for b in range(2,100):
            if a**b == n:
                return 1
    return 0
