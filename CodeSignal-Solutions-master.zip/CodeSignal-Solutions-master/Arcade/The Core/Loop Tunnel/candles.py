def candles(candlesNumber, makeNew):
    left = 0
    tot_candels = 0

    while (candlesNumber > 0):
        tot_candels += candlesNumber
        tmp = candlesNumber + left
        candlesNumber = math.floor(tmp / makeNew)
        print(candlesNumber)
        left = tmp % makeNew
        
    return tot_candels
