def countSumOfTwoRepresentations2(n, l, r):
    result = 0
    for a in range(l,r+1):
        b = n - a
        if(b >= l and b <= r and b >= a):
            result+=1
    return result
