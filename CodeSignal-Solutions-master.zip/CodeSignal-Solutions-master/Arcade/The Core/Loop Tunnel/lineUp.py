def lineUp(commands):
    rightMen=["S"] 
    wrongMen=["S"] 
    count=0 
    inverse={"L":"R","R":"L","A":"A"} 
    lookup ={"EL":"S","EA":"W","ER":"N","NL":"E","NA":"S","NR":"W","WL":"N","WA":"E","WR":"S","SL":"W","SA":"N","SR":"E"}  
    for i in commands: 
        rightMen.append(lookup[rightMen[-1]+i]) 
        i=inverse[i] 
        wrongMen.append(lookup[wrongMen[-1]+i]) 
        if(rightMen[-1:]==wrongMen[-1:]): 
            count+=1 
    return count 
