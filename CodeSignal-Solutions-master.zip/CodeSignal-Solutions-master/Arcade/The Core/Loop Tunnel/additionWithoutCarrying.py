def additionWithoutCarrying(param1, param2):
    param1_1 = [int(i) for i in str(param1)]
    param2_2 = [int(i) for i in str(param2)]
    pad = abs(len(param1_1)-len(param2_2))
    if len(param1_1) < len(param2_2):
        for i in range(pad):
            param1_1.insert(0,0)
    else:
        for i in range(pad):
            param2_2.insert(0,0)
    ans = [(x+y)%10 for x,y in zip(param1_1,param2_2)]
    ans = int(''.join(str(i) for i in ans))
    return ans
