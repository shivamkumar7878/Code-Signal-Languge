def countBlackCells(n, m):
    from fractions import gcd
    
    return (n+m+gcd(n,m))-2
