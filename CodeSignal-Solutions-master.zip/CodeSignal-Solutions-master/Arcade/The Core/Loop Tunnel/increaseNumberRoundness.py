def increaseNumberRoundness(n):
    manipulandum = str(n)
    roundness = len(manipulandum)-len(manipulandum.rstrip('0'))
    if str(n).count('0') > roundness:
        return 1
    else:
        return 0
