def rounders(value):
    value1 = [int(i) for i in str(value)]
    for i in reversed(range(len(value1))):
        if i > 0:
            if value1[i] >= 5:
                value1[i] = 0
                value1[i-1] += 1
    
            if value1[i] < 5:
                value1[i] = 0                
    return int(''.join(str(i) for i in value1))
    
    
