def createArray(size):
    return [1]*size
