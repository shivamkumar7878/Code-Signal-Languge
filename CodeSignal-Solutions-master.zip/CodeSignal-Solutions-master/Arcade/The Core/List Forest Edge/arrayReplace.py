def arrayReplace(inputArray, elemToReplace, substitutionElem):
    return [substitutionElem if elemToReplace==x else x for x in inputArray]
