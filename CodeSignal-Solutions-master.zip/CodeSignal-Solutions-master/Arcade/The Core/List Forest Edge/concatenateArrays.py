def concatenateArrays(a, b):
    return a+b
