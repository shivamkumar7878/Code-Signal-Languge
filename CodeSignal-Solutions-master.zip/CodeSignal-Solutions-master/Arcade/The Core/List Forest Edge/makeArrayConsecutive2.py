def makeArrayConsecutive2(sequence):
    return max(sequence)-min(sequence)-len(sequence)+1
