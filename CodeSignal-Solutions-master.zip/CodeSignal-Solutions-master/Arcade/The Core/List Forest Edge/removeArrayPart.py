def removeArrayPart(inputArray, l, r):
    for i in range(l,r):
        del inputArray[i]
    return inputArray
