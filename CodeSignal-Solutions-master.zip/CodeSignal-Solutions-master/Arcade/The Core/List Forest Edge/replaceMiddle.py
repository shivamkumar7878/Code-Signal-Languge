def replaceMiddle(arr):
    me = 0
    if len(arr)%2==0:
        me = arr[round(len(arr)/2)-1] + arr[round(len(arr)/2)]
        del arr[round(len(arr)/2)-1:round(len(arr)/2)+1]
        arr.insert(round(len(arr)/2),me)
    else:
        me = arr[math.floor(len(arr)/2)]        
    return arr
