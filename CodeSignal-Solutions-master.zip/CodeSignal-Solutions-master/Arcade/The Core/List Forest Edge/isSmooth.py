def isSmooth(arr):
    y= len(arr)/2
    return arr[y+1]
