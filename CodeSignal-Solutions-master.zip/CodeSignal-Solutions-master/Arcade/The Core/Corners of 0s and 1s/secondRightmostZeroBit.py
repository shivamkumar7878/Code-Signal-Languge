def secondRightmostZeroBit(n):
    return 2**(str(bin(n))[:1:-1].find('0', str(bin(n))[:1:-1].find('0')+1))
