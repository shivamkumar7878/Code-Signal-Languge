def killKthBit(n, k):
    return int(bin(n & ~ (1<<k-1)),2) if (n >> k-1) & 1 == 1 else int(bin(n),2)
