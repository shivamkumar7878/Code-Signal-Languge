def differentRightmostBit(n, m):
    return 2**((str(bin(n^m))[2:])[::-1].index('1'))
