def equalPairOfBits(n, m):
    return bin(~(n ^ m))
