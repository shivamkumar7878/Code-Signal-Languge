def arrayPacking(a):
    print('{0:08b}'.format(a[2]))
