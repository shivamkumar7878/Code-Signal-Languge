def candies(n, m):
    return (m/n)*n
