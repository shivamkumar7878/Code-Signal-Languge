def largestNumber(n):
    return ((10**n)-1)
