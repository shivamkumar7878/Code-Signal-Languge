def phoneCall(min1, min2_10, min11, S):
    if S > 10:
        m = 10
        rupees_left = S - min1 - min2_10*9
        m += rupees_left / min11
        return m
    else:
        m = 1
        rupees_left = S - min1 
        m += rupees_left / min2_10
        return m
    
    
    
