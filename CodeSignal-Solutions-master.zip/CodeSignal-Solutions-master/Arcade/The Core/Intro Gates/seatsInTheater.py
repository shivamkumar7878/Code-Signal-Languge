def seatsInTheater(nCols, nRows, col, row):
    return ((nCols*nRows) - (nCols-col+1)*row - nRows*(col-1))
    
    
