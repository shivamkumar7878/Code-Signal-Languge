def maxMultiple(divisor, bound):
    if bound%divisor != 0:
        return divisor*(bound/divisor)
    else:
        return divisor * (bound/divisor)
        
