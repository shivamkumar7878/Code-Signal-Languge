def addTwoDigits(n):
    return n/10 + n%10
