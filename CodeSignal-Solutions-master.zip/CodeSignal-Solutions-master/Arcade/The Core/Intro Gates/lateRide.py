def lateRide(n):
    m = n/60 
    p = n% 60
    return m/10 + m%10 + p/10 + p%10
