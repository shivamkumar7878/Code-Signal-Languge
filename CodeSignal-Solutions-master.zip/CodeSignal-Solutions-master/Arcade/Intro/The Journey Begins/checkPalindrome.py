def checkPalindrome(inputString):
    return True if inputString==inputString[::-1] else False
