def shapeArea(n):
    m=n
    i=1
    while i<n:    
        m += 2*n -1       
        print(m)
        i+=1

    return m
