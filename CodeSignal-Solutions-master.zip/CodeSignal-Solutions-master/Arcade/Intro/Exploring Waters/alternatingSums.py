def alternatingSums(a):
    return [sum(a[::2]),sum(a[1::2])]
