def absoluteValuesSumMinimization(a):
    return a[len(a)//2-1] if len(a) % 2 == 0 else a[len(a)//2]
