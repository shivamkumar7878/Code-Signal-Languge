def differentSymbolsNaive(s):
    return len(set(s))
