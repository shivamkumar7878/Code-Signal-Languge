def firstDigit(inputString):
    for i in inputString:
        if i.isdigit():
            return i
