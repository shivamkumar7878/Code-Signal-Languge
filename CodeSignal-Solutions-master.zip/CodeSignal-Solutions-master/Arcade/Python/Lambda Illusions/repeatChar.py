repeatChar = lambda ch,n: ch*n
