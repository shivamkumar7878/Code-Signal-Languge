def multiplicationTable(n):
    return [[cols*rows for cols in range(1,n+1)] for rows in range(1,n+1)]
