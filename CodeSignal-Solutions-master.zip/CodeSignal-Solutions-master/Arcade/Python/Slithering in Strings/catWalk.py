def catWalk(code):
    return " ".join(code.split())
