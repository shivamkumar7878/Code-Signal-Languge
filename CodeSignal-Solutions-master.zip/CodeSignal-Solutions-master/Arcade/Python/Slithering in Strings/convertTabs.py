def convertTabs(code, x):
    return code.replace("\t", " "*x)
