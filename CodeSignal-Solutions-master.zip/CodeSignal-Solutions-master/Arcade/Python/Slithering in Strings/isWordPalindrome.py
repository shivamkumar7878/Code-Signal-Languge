def isWordPalindrome(word):
    return word == word[::-1]
