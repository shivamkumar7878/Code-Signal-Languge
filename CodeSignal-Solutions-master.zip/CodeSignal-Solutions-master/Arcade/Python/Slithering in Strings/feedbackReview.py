import textwrap

def feedbackReview(feedback, size):
    return textwrap.wrap(feedback, size)
