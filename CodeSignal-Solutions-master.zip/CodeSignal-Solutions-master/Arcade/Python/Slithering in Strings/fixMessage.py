def fixMessage(message):
    return message.capitalize()
