def getCommit(commit):
    return commit.lstrip('0!?+')
