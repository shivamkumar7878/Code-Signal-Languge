def baseConversion(n, x):
    return hex(int(n,x))[2:]
