def countBits(n):
    return n.bit_length()
