def modulus(n):
    if isinstance(n,int) :
        return n % 2
    else:
        return -1
