def listsConcatenation(lst1, lst2):
    res = lst1
    res.append(lst2)
    return res
