def printList(lst):
    return "This is your list: [{}]".format(", ".join([i for i in map(str, lst)]))
