def createHistogram(ch, data):
    return [ch*i for i in data]
