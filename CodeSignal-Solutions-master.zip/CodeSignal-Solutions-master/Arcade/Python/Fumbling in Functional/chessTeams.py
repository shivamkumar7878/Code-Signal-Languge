def chessTeams(smarties, cleveries):
    return [[i,j] for i,j in zip(smarties,cleveries)]
