def uniqueCharacters(document):
    return sorted(set(document))
