def twinsScore(b, m):
    return [b[i]+m[i] for i in range(len(b))]
