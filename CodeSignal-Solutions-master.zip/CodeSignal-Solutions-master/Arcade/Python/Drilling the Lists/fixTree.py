def fixTree(tree):
    return [e.strip().center(len(e)) for e in tree]
