def checkParticipants(participants):
    return []i for i in range(len(participants)) if i > participants[i]]
